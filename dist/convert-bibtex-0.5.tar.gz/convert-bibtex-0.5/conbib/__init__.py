"""
    conbib
    ~~~~~~

    Conversions and cite key generation for BibTeX files.

    :copyright: (c) 2014 by Li Research Group.
    :license: MIT, see LICENSE for more details.
"""

# Program metadata
__title__ = "convert-bibtex"
__version__ = "0.5"
__release_date__ = "Jul 31, 2014"
__author__ = "Joseph W. May"
__copyright__ = "Copyright (c) 2014 Li Research Group"
