convertBibTeX
=============

Conversions and cite key generation for BibTeX files
